function execute() {
    return Response.success([
        {title: "Tiên hiệp", input: "/tien-hiep-tu-chan", script: "gen.js"},
        {title: "Huyền ảo", input: "/huyen-ao-huyen-huyen", script: "gen.js"},
        {title: "Võng Du", input: "/vong-du", script: "gen.js"},
        {title: "Trùng Sinh", input: "/trung-sinh", script: "gen.js"},
        {title: "Dị giới", input: "/di-gioi", script: "gen.js"},
        {title: "Đô Thị", input: "/do-thi", script: "gen.js"},
        {title: "Mạt thế", input: "/mat-the", script: "gen.js"},
        {title: "Khoa huyễn", input: "/khoa-huyen", script: "gen.js"},
        {title: "Dị Năng", input: "/di-nang", script: "gen.js"},
        {title: "Xuyên Không", input: "/xuyen-khong", script: "gen.js"},
        {title: "Đồng Nhân", input: "/dong-nhan", script: "gen.js"},
        {title: "Kiếm Hiệp", input: "/kiem-hiep", script: "gen.js"},
        {title: "Lịch sử", input: "/lich-su", script: "gen.js"},
        {title: "Nữ hiệp", input: "/nu-hiep", script: "gen.js"},
        {title: "Quân sự", input: "/quan-su", script: "gen.js"},
        {title: "Ngôn Tình", input: "/ngon-tinh", script: "gen.js"},
        {title: "Spoil", input: "/spoil", script: "gen.js"},
    ])
}