let BASE_URL = 'https://trumtruyen.xyz';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}